package com.metaldetector;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.hoho.android.usbserial.driver.UsbSerialDriver;
import com.hoho.android.usbserial.driver.UsbSerialPort;
import com.hoho.android.usbserial.driver.UsbSerialProber;
import org.json.JSONObject;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private static final String ACTION_USB_PERMISSION = "com.metaldetector.USB_PERMISSION";
    private UsbManager usbManager;
    private UsbSerialPort serialPort;
    private ExecutorService executor = Executors.newSingleThreadExecutor();
    private Handler handler = new Handler(Looper.getMainLooper());
    private boolean reading = false;
    private StringBuilder buffer = new StringBuilder();

    private TextView tvStatus, tvMagnitude, tvMetal, tvDepth;
    private TextView tvX, tvY, tvZ, tvHeading;
    private TextView tvMetalThresh, tvVoidThresh;
    private SeekBar sbMetal, sbVoid;
    private View btnStart;
    private View metalBar, voidBar;

    private float metalThreshold = 500f;
    private float voidThreshold = 100f;

    private final BroadcastReceiver usbReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (ACTION_USB_PERMISSION.equals(intent.getAction())) {
                UsbDevice device = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                    connectToDevice(device);
                } else {
                    updateStatus("تم رفض الإذن");
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usbManager = (UsbManager) getSystemService(USB_SERVICE);

        tvStatus = findViewById(R.id.tvStatus);
        tvMagnitude = findViewById(R.id.tvMagnitude);
        tvMetal = findViewById(R.id.tvMetal);
        tvDepth = findViewById(R.id.tvDepth);
        tvX = findViewById(R.id.tvX);
        tvY = findViewById(R.id.tvY);
        tvZ = findViewById(R.id.tvZ);
        tvHeading = findViewById(R.id.tvHeading);
        tvMetalThresh = findViewById(R.id.tvMetalThresh);
        tvVoidThresh = findViewById(R.id.tvVoidThresh);
        sbMetal = findViewById(R.id.sbMetal);
        sbVoid = findViewById(R.id.sbVoid);
        btnStart = findViewById(R.id.btnStart);
        metalBar = findViewById(R.id.metalBar);
        voidBar = findViewById(R.id.voidBar);

        sbMetal.setMax(2000);
        sbMetal.setProgress(500);
        sbVoid.setMax(500);
        sbVoid.setProgress(100);

        sbMetal.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) {
                metalThreshold = p;
                tvMetalThresh.setText(String.valueOf(p));
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });

        sbVoid.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) {
                voidThreshold = p;
                tvVoidThresh.setText(String.valueOf(p));
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });

        btnStart.setOnClickListener(v -> {
            if (!reading) startReading();
            else stopReading();
        });

        registerReceiver(usbReceiver, new IntentFilter(ACTION_USB_PERMISSION));
    }

    private void startReading() {
        List<UsbSerialDriver> drivers = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager);
        if (drivers.isEmpty()) {
            updateStatus("لا يوجد جهاز USB - تأكد من OTG");
            return;
        }
        UsbSerialDriver driver = drivers.get(0);
        UsbDevice device = driver.getDevice();
        if (!usbManager.hasPermission(device)) {
            PendingIntent pi = PendingIntent.getBroadcast(this, 0,
                new Intent(ACTION_USB_PERMISSION), PendingIntent.FLAG_IMMUTABLE);
            usbManager.requestPermission(device, pi);
            return;
        }
        connectToDevice(device);
    }

    private void connectToDevice(UsbDevice device) {
        List<UsbSerialDriver> drivers = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager);
        if (drivers.isEmpty()) return;
        UsbSerialDriver driver = drivers.get(0);
        UsbDeviceConnection connection = usbManager.openDevice(device);
        if (connection == null) {
            updateStatus("فشل فتح الاتصال");
            return;
        }
        serialPort = driver.getPorts().get(0);
        try {
            serialPort.open(connection);
            serialPort.setParameters(115200, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE);
            reading = true;
            updateStatus("متصل ✅");
            ((TextView) btnStart).setText("إيقاف");
            startReadLoop();
        } catch (Exception e) {
            updateStatus("خطأ: " + e.getMessage());
        }
    }

    private void startReadLoop() {
        executor.submit(() -> {
            byte[] buf = new byte[256];
            while (reading) {
                try {
                    int len = serialPort.read(buf, 200);
                    if (len > 0) {
                        String chunk = new String(buf, 0, len);
                        buffer.append(chunk);
                        int nl;
                        while ((nl = buffer.indexOf("\n")) >= 0) {
                            String line = buffer.substring(0, nl).trim();
                            buffer.delete(0, nl + 1);
                            if (line.startsWith("{")) parseLine(line);
                        }
                    }
                } catch (Exception e) {
                    if (reading) handler.post(() -> updateStatus("انقطع الاتصال"));
                    break;
                }
            }
        });
    }

    private void parseLine(String line) {
        try {
            JSONObject j = new JSONObject(line);
            float x = (float) j.getDouble("x");
            float y = (float) j.getDouble("y");
            float z = (float) j.getDouble("z");
            float mag = (float) j.getDouble("magnitude");
            float heading = (float) j.getDouble("heading");
            boolean metal = j.getBoolean("metal");
            float depth = (float) j.getDouble("depth");

            handler.post(() -> updateUI(x, y, z, mag, heading, metal, depth));
        } catch (Exception ignored) {}
    }

    private void updateUI(float x, float y, float z, float mag, float heading, boolean metal, float depth) {
        tvX.setText(String.format("%.1f", x));
        tvY.setText(String.format("%.1f", y));
        tvZ.setText(String.format("%.1f", z));
        tvHeading.setText(String.format("%.1f°", heading));
        tvMagnitude.setText(String.format("%.1f μT", mag));
        tvDepth.setText(String.format("%.2f متر", depth));

        // Metal bar width
        float metalPct = Math.min(mag / 2000f, 1f);
        metalBar.getLayoutParams().width = (int)(metalPct * metalBar.getRootView().getWidth() * 0.8f);
        metalBar.requestLayout();

        // Void bar
        float voidPct = Math.min(mag / 500f, 1f);
        voidBar.getLayoutParams().width = (int)(voidPct * voidBar.getRootView().getWidth() * 0.8f);
        voidBar.requestLayout();

        if (mag > metalThreshold) {
            tvMetal.setText("⚠️ معدن مكتشف!");
            tvMetal.setTextColor(Color.RED);
            tvMagnitude.setTextColor(Color.RED);
        } else if (mag < voidThreshold) {
            tvMetal.setText("🕳️ فراغ");
            tvMetal.setTextColor(Color.BLUE);
            tvMagnitude.setTextColor(Color.BLUE);
        } else {
            tvMetal.setText("✅ لا يوجد معدن");
            tvMetal.setTextColor(Color.GREEN);
            tvMagnitude.setTextColor(Color.GREEN);
        }
    }

    private void stopReading() {
        reading = false;
        try { if (serialPort != null) serialPort.close(); } catch (Exception ignored) {}
        updateStatus("متوقف");
        ((TextView) btnStart).setText("▶ ابدأ الكشف");
    }

    private void updateStatus(String msg) {
        handler.post(() -> tvStatus.setText(msg));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopReading();
        unregisterReceiver(usbReceiver);
    }
}
